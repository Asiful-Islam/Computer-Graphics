#include <windows.h>
#include <GL/glut.h>
# define PI           3.14159265358979323846
#include<math.h>>
GLfloat i=0;
void idle()
{

    glutPostRedisplay();
}


void display() {
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	glPushMatrix();
    glRotatef(i,.0,.0,.1);
     glBegin(GL_TRIANGLES);/*car3*/

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(-.1f, -.1f);
	glVertex2f(.5f, -.3f);
	glVertex2f(.1f, .1f);

	glEnd();
	glPopMatrix();
	i=i+1;

    /*glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.0f, .0f);
	glVertex2f(.5f, .5f);
     glEnd();

    glPushMatrix();
    glRotatef(i,.0,.0,.1);
    glTranslatef(.3f,.4f,0);
    glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.0f, .0f);
	glVertex2f(.3f, .2f);

	glEnd();
    glPopMatrix();
	i=i+1;
	glLoadIdentity();*/

	glFlush();
}


int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Setup");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	glutIdleFunc(idle);
	glutMainLoop();
	return 0;
}
