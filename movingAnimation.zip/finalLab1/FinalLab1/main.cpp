#include<cstdio>

#include <GL/gl.h>
#include <GL/glut.h>



void display() {
   glClear(GL_COLOR_BUFFER_BIT);




   glBegin(GL_QUADS);
      glColor3f(1.0f, 0.0f, 0.0f);
      glVertex2f(0.0f, 0.1f);
      glVertex2f( 0.1f, 0.15f);
      glVertex2f( 0.1f,  0.2f);
      glVertex2f(0.0f,  0.25f);
       glEnd();

     glBegin(GL_QUADS);
      glColor3f(1.0f, 0.0f, 0.0f);

      glVertex2f( 0.1f, 0.15f);
      glVertex2f( 0.2f, 0.1f);
      glVertex2f( 0.2f,  0.25f);
      glVertex2f(0.1f,  0.2f);




   glFlush();
}



int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(320, 320);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Translation Animation");
   glutDisplayFunc(display);

   glutMainLoop();
   return 0;
}










