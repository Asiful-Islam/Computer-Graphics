#include <windows.h>
#include <GL/glut.h>
# define PI           3.14159265358979323846
#include<math.h>
GLfloat i=0;
//moving car

GLfloat position = 0.0f;
    GLfloat speed = 0.1f;
    GLfloat position1 = 0.0f;
    GLfloat speed1 = 0.1f;

    //GLfloat position2 = 0.0f;
    //GLfloat speed2 = 0.1f;
    void update(int value)
	{
	    if(position<-1.5)
            position=1.0f;
            position-=speed;
            glutPostRedisplay();
            glutTimerFunc(100,update,0);
	}

	void update2(int value)
	{
	    if(position1<-1.5)
            position1=1.0f;
            position1-=speed1;
            glutPostRedisplay();
            glutTimerFunc(100,update2,0);
	}

	void update1(int value)
	{
	    if(position1>1.5)
            position1=-1.0f;
            position1+=speed1;
            glutPostRedisplay();
            glutTimerFunc(50,update1,0);
	}

	void init() {
   glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
   }

void idle()
{

    glutPostRedisplay();
}
void circle(GLfloat x,GLfloat y,GLfloat radius,int r,int g, int b)
{
        int i;
        int triangleAmount = 100; //# of triangles used to draw circle

        //GLfloat radius = 0.8f; //radius
        GLfloat twicePi = 2.0f * PI;

        glBegin(GL_TRIANGLE_FAN);
        glColor3ub(r,g,b);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();


}
void SpecialInput(int key, int x, int y)
    {  switch(key)
    {
     case GLUT_KEY_UP:

     break;
     case GLUT_KEY_DOWN:
     break;
     case GLUT_KEY_LEFT:
         glutTimerFunc(100, update2, 0);
     break;
     case GLUT_KEY_RIGHT:

         glutTimerFunc(100, update1, 0);
     break;
}
glutPostRedisplay();}

void display() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	glLineWidth(5.5);


     glBegin(GL_QUADS);

	glColor3f(134.0f, 121.0f, 121.0f);
	glVertex2f(-1.0f, .2f);
	glVertex2f(-1.0f, -.8f);
	glVertex2f(1.0f, -.8f);
	glVertex2f(1.0f, .2f);
	glEnd();

	 glBegin(GL_QUADS);/*footpath*/

	glColor3ub(0.0f, 255.0f, 255.0f);
	glVertex2f(1.0f, .3f);
	glVertex2f(1.0f, 1.0f);
	glVertex2f(-1.0f, 1.0f);
	glVertex2f(-1.0f, .3f);
	glEnd();

     glBegin(GL_QUADS);/*background*/

	glColor3f(139.0f, 0.0f, 0.0f);
	glVertex2f(-1.0f, .2f);
	glVertex2f(1.0f, .2f);
	glVertex2f(1.0f, .3f);
	glVertex2f(-1.0f, .3f);
	glEnd();


    glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(-1.0f, -.3f);
	glVertex2f(-0.7f, -.3f);
	glEnd();

	 glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(-0.5f, -.3f);
	glVertex2f(-0.2f, -.3f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(0.0f, -.3f);
	glVertex2f(.3f, -.3f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.5f, -.3f);
	glVertex2f(.8f, -.3f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.10f, -.3f);
	glVertex2f(.13f, -.3f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.15f, -.3f);
	glVertex2f(.18f, -.3f);
	glEnd();

	//moving car

    glLoadIdentity();
	glPushMatrix();
	glTranslatef(position,0.0f,0.0f);
glBegin(GL_QUADS);/*car*/

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(.5f, -.4f);
	glVertex2f(.5f, -.6f);
	glVertex2f(.8f, -.6f);
	glVertex2f(.8f, -.4f);
	glEnd();
	circle(.55,-.6,.04,0,0,0);
    circle(.75,-.6,.04,0,0,0);

    glBegin(GL_QUADS);/*car*/

	glColor3ub(128.0, 128.0, 128.0);
	glVertex2f(.52f, -.42f);
	glVertex2f(.52f, -.5f);
	glVertex2f(.78f, -.5f);
	glVertex2f(.78f, -.42f);
	glEnd();
    glPopMatrix();





    glLoadIdentity();
	glPushMatrix();
	glTranslatef(position1,0.0f,0.0f);
    glBegin(GL_QUADS);/*car3*/

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(-.3f, 0.0f);
	glVertex2f(-.3f, -.1f);
	glVertex2f(-.8f, -.1f);
	glVertex2f(-.8f, 0.0f);
	glEnd();
	circle(-.4,-.1,.04,0,0,0);
    circle(-.7,-.1,.04,0,0,0);
     glPopMatrix();


    circle(-.9,.8,.1,255,255,0);/*Sun*/

    circle(-.6,.8,.1,255,255,255);/*sky*/
    circle(-.5,.8,.1,255,255,255);/*sky*/
     circle(-.55,.7,.1,255,255,255);/*sky*/

     circle(.6,.9,.1,255,255,255);/*sky*/
     circle(.5,.9,.1,255,255,255);/*sky*/
     circle(.55,.8,.1,255,255,255);/*sky*/

	glBegin(GL_QUADS);/*Tree*/

	glColor3ub(168.0, 70.0, 50.0);
	glVertex2f(-.66f, .2f);
	glVertex2f(-.75f, .2f);
	glVertex2f(-.75f, .55f);
	glVertex2f(-.66f, .55f);
	glEnd();
    circle(-.6,.55,.1,78,168,50);
    circle(-.8,.55,.1,78,168,50);
    circle(-.7,.66,.1,78,168,50);


    glBegin(GL_QUADS);/*windMill*/
	glColor3ub(0.0, 64.0, 255.0);
	glVertex2f(-.1f, .3f);
	glVertex2f(-.1f, .7f);
	glVertex2f(-.2f, .7f);
	glVertex2f(-.2f, .3f);

	glEnd();


    glLoadIdentity();
    glTranslatef(-.2f,.7f,0);

	glPushMatrix();
   glRotatef(i,.0,.0,.1);

    glBegin(GL_TRIANGLES);
	glColor3ub(230.0, 0.0, 0.0);
    glVertex2f(0.0f, 0.0f);
	glVertex2f(-.22f, .13f);
	glVertex2f(-.25f, .1f);
     glEnd();


     glBegin(GL_TRIANGLES);
	glColor3ub(230.0, 0.0, 0.0);
    glVertex2f(0.0f, 0.0f);
	glVertex2f(0.2f, .13f);
	glVertex2f(.27f, .1f);
     glEnd();

     glBegin(GL_TRIANGLES);
	glColor3ub(230.0, 0.0, 0.0);
    glVertex2f(0.0f, 0.0f);
	glVertex2f(-.03f, -.3f);
	glVertex2f(0.02f, -.27f);
     glEnd();





     glPopMatrix();
	i=i+1;//
	glLoadIdentity();

     /*windMill*/

	glBegin(GL_QUADS);/*building*/
	glColor3ub(50.0, 168.0, 149.0);
	glVertex2f(.2f, .3f);
	glVertex2f(.4f, .3f);
	glVertex2f(.4f, .9f);
	glVertex2f(.2f, .9f);
	glEnd();

	glBegin(GL_LINES);/*buildingglass*/
	glColor3ub(255.0, 0.0, 255.0);
	glVertex2f(.2f, .7f);
	glVertex2f(.4f, .7f);
	glEnd();

	glBegin(GL_LINES);/*buildingglass*/
	glColor3ub(255.0, 0.0, 255.0);
	glVertex2f(.2f, .5f);
	glVertex2f(.4f, .5f);
	glEnd();

    glTranslatef(.5,0,0);
	glBegin(GL_QUADS);/*buildingTrans*/
	glColor3ub(50.0, 168.0, 149.0);
	glVertex2f(.2f, .3f);
	glVertex2f(.4f, .3f);
	glVertex2f(.4f, .9f);
	glVertex2f(.2f, .9f);
	glEnd();
    glLoadIdentity();

    glBegin(GL_LINES);/*buildingglass*/
	glColor3ub(0.0, 255.0, 0.0);
	glVertex2f(.7f, .5f);
	glVertex2f(.9f, .5f);
	glEnd();
	glBegin(GL_LINES);/*buildingglass*/
	glColor3ub(0.0, 255.0, 0.0);
	glVertex2f(.7f, .7f);
	glVertex2f(.9f, .7f);
	glEnd();

    glBegin(GL_QUADS);/*building*/
	glColor3ub(168.0, 50.0, 100.0);
	glVertex2f(.45f, .3f);
	glVertex2f(.6f, .3f);
	glVertex2f(.6f, .8f);
	glVertex2f(.45f, .8f);
	glEnd();

	glBegin(GL_LINES);/*buildingglass*/
	glColor3ub(255.0, 0.0, 255.0);
	glVertex2f(.45f, .6f);
	glVertex2f(.6f, .6f);
	glEnd();
	glBegin(GL_LINES);/*buildingglass*/
	glColor3ub(0.0, 255.0, 0.0f);
	glVertex2f(.45f, .4f);
	glVertex2f(.6f, .4f);
	glEnd();

	glBegin(GL_QUADS);/*building*/
	glColor3ub(102.0, 102.0, 255.0);
	glVertex2f(.6f, .3f);
	glVertex2f(.78f, .3f);
	glVertex2f(.78f, .7f);
	glVertex2f(.6f, .7f);
	glEnd();

	glBegin(GL_LINES);/*buildingglass*/
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.6f, .4f);
	glVertex2f(.78f, .4f);
	glEnd();

	glBegin(GL_LINES);/*buildingglass*/
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.6f, .6f);
	glVertex2f(.78f, .6f);
	glEnd();

    glLoadIdentity();
    glTranslatef(0,.1,0);
    glScalef(.5,.5,0);
    glBegin(GL_QUADS);/*Tree*/
	glColor3ub(168.0, 70.0, 50.0);
	glVertex2f(-.66f, .2f);
	glVertex2f(-.75f, .2f);
	glVertex2f(-.75f, .55f);
	glVertex2f(-.66f, .55f);
	glEnd();
    circle(-.6,.55,.1,78,168,50);
    circle(-.8,.55,.1,78,168,50);
    circle(-.7,.66,.1,78,168,50);
    glLoadIdentity();


	glFlush();


}


int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Moving Animation");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	glutIdleFunc(idle);
	glutTimerFunc(100,update,0);
	glutTimerFunc(50,update1,0);
	glutTimerFunc(50,update2,0);
	init();
	glutSpecialFunc(SpecialInput);
	glutMainLoop();
	return 0;
}
