#include<windows.h>
#include<GL/glut.h>
void display()
{
        glClearColor(1.0f,1.0f,1.0f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        glEnable(GL_LIGHTING);
        GLfloat global_ambient[]={1.9,0.0,0.0,0.1};
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT,global_ambient);

        glBegin(GL_QUADS);
        glColor3f(0,1,0);
        glVertex2f(.4,.4);
        glVertex2f(0,.4);
        glVertex2f(0,0);
        glVertex2f(.4,0);
        glEnd();
        glDisable(GL_LIGHTING);

        glBegin(GL_QUADS);
        glColor3f(0,1,0);
        glVertex2f(-.4,0);
        glVertex2f(-.4,.4);
        glVertex2f(-.8,.4);
        glVertex2f(-.8,0);
        glEnd();

        glFlush();

}
int main(int argc, char**argv)
{
    glutInit(&argc,argv);
    glutCreateWindow("OpenGL Setup Test");
    glutInitWindowSize(320,320);
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
