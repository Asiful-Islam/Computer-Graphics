#include <windows.h>
#include <GL/glut.h>
# define PI           3.14159265358979323846
#include<math.h>>
void circle(GLfloat x,GLfloat y,GLfloat radius,int r,int g, int b)
{
        int i;
        int triangleAmount = 100; //# of triangles used to draw circle

        //GLfloat radius = 0.8f; //radius
        GLfloat twicePi = 2.0f * PI;

        glBegin(GL_TRIANGLE_FAN);
        glColor3ub(r,g,b);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
		glEnd();


}
void display() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	glLineWidth(5.5);
	circle(-.9,.8,.1,255,255,255);

     glBegin(GL_QUADS);

	glColor3f(134.0f, 121.0f, 121.0f);
	glVertex2f(-1.0f, .2f);
	glVertex2f(-1.0f, -.8f);
	glVertex2f(1.0f, -.8f);
	glVertex2f(1.0f, .2f);
	glEnd();

	 glBegin(GL_QUADS);/*footpath*/

	glColor3f(139.0f, 0.0f, 0.0f);
	glVertex2f(-1.0f, .2f);
	glVertex2f(1.0f, .2f);
	glVertex2f(1.0f, .3f);
	glVertex2f(-1.0f, .3f);
	glEnd();




    glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(-1.0f, -.3f);
	glVertex2f(-0.7f, -.3f);
	glEnd();

	 glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(-0.5f, -.3f);
	glVertex2f(-0.2f, -.3f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(0.0f, -.3f);
	glVertex2f(.3f, -.3f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.5f, -.3f);
	glVertex2f(.8f, -.3f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.10f, -.3f);
	glVertex2f(.13f, -.3f);
	glEnd();

	glBegin(GL_LINES);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex2f(.15f, -.3f);
	glVertex2f(.18f, -.3f);
	glEnd();



	glBegin(GL_QUADS);/*car*/

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(.5f, -.4f);
	glVertex2f(.5f, -.6f);
	glVertex2f(.8f, -.6f);
	glVertex2f(.8f, -.4f);
	glEnd();
	circle(.55,-.6,.04,0,0,0);
    circle(.75,-.6,.04,0,0,0);

    glBegin(GL_QUADS);/*car2*/

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(-.5f, -.4f);
	glVertex2f(-.5f, -.6f);
	glVertex2f(-.8f, -.6f);
	glVertex2f(-.8f, -.4f);
	glEnd();
	circle(-.55,-.6,.04,0,0,0);
    circle(-.75,-.6,.04,0,0,0);

    glBegin(GL_QUADS);/*car3*/

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(-.3f, 0.0f);
	glVertex2f(-.3f, -.1f);
	glVertex2f(-.8f, -.1f);
	glVertex2f(-.8f, 0.0f);
	glEnd();
	circle(-.4,-.1,.04,0,0,0);
    circle(-.7,-.1,.04,0,0,0);



	glBegin(GL_QUADS);/*building*/

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(-.7f, .3f);
	glVertex2f(-.8f, .3f);
	glVertex2f(-.8f, .6f);
	glVertex2f(-.7f, .6f);
	glEnd();

	glBegin(GL_QUADS);/*building*/

	glColor3f(255.0f, 140.0f, 102.0f);
	glVertex2f(-.6f, .3f);
	glVertex2f(-.5f, .3f);
	glVertex2f(-.5f, .7f);
	glVertex2f(-.6f, .7f);
	glEnd();

	glBegin(GL_QUADS);/*building*/

	glColor3f(0.0f, 0.0f, 255.0f);
	glVertex2f(-.4f, .3f);
	glVertex2f(-.2f, .3f);
	glVertex2f(-.2f, .8f);
	glVertex2f(-.4f, .8f);
	glEnd();

	glBegin(GL_QUADS);/*building*/

	glColor3f(102.0f, 102.0f, 255.0f);
	glVertex2f(-.1f, .3f);
	glVertex2f(.1f, .3f);
	glVertex2f(.1f, .7f);
	glVertex2f(-.1f, .7f);
	glEnd();




	glBegin(GL_QUADS);/*building*/

	glColor3f(1.0f, 1.0f, 0.0f);
	glVertex2f(.5f, .3f);
	glVertex2f(.8f, .3f);
	glVertex2f(.8f, .9f);
	glVertex2f(.5f, .9f);
	glEnd();



	glFlush();
}


int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Setup");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
