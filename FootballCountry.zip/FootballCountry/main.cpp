
#include <windows.h>
#include <GL/glut.h>
# define PI           3.14159265358979323846
#include<math.h>>

void display() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	glClear(GL_COLOR_BUFFER_BIT);


    glBegin(GL_QUADS);

	glColor3f(0.0f, 0.0f, 255.0f);

	glVertex2f(-.2f, .4f);
	glVertex2f(-.6f, .4f);
	glVertex2f(-.6f, -.4f);
	glVertex2f(-.2f, -.4f);
	glEnd();



	glBegin(GL_QUADS);


	glColor3f(255.0f, 255.0f, 255.0f);
	glVertex2f(.2f, .4f);
	glVertex2f(-.2f, .4f);
	glVertex2f(-.2f, -.4f);
	glVertex2f(.2f, -.4f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(255.0f, 0.0f, 0.0f);

	glVertex2f(.6f, .4f);
	glVertex2f(.2f, .4f);
	glVertex2f(.2f, -.4f);
	glVertex2f(.6f, -.4f);
	glEnd();


	glFlush();
}


int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("OpenGL Setup");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
