#include <windows.h>
#include <GL/glut.h>
#include<math.h>>
# define PI           3.14159265358979323846

GLfloat position = 0.0f;
GLfloat position2 = 0.0f;
GLfloat speed = 0.1f;

void update(int value) {




if(position < -1.0)
        position = 1.0f;

    position -= speed;


	glutPostRedisplay();


	glutTimerFunc(50, update, 0);
}


void update3(int value) {
    if(position2 <-1.0)
        position2 = 1.0f;
    position2 -= speed;
	glutPostRedisplay();
	glutTimerFunc(50, update3, 0);
}

void update4(int value) {


if(position > 1.0)
        position = -1.0f;

    position += speed;


	glutPostRedisplay();


	glutTimerFunc(50, update4, 0);
}







GLfloat j=0.0f;
void init()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

/*void idle()
{
    glutPostRedisplay();

}*/

void handlekeypress(unsigned char key, int x, int y)
{  switch(key)
{
case GLUT_KEY_UP:
glutTimerFunc(50, update, 0);
break;
case 's':
      glutTimerFunc(50, update, 0);


break;
case 'd':
     glutTimerFunc(50, update3, 0);

break;
case 'b':
    glutTimerFunc(50, update4, 0);

break;
}
glutPostRedisplay();}


void handleMouse(int button, int state,int x,int y)
{
    if(button == GLUT_LEFT_BUTTON)
    {
        speed+=0.1f;
    }
    if(button==GLUT_RIGHT_BUTTON)
    {
        speed-=0.1f;
    }
    glutPostRedisplay();
}


void display()
{

    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

     int i;
     glColor3ub(0, 128, 255);

	GLfloat x=0.0f; GLfloat y=0.0f; GLfloat radius =.1f;
	int triangleAmount = 10;


	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {

                glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();






glLoadIdentity();
	glPushMatrix();
    glRotatef(j,0.0,0.0,0.1);




   glBegin(GL_QUADS);
	glColor3ub(0, 255, 255);

	glVertex2f(.05,-.1); //fan1
	glVertex2f(-.05,-.1);
	glVertex2f(-.05,-.15);
	glVertex2f(.05,-.15);

	glVertex2f(.1,-.15);
	glVertex2f(-.1,-.15);
	glVertex2f(-.1,-.7);
	glVertex2f(.1,-.7);

	glVertex2f(.15,.05);//fan2
	glVertex2f(.1,.05);
	glVertex2f(.1,-.05);
	glVertex2f(.15,-.05);

	glVertex2f(.15,.1);
	glVertex2f(.7,.1);
	glVertex2f(.7,-.1);
	glVertex2f(.15,-.1);




	glVertex2f(.05,.1); //fan3
	glVertex2f(-.05,.1);
	glVertex2f(-.05,.15);
	glVertex2f(.05,.15);

	glVertex2f(.1,.15);
	glVertex2f(-.1,.15);
	glVertex2f(-.1,.7);
	glVertex2f(.1,.7);



	glVertex2f(-.15,.05); //fan4
	glVertex2f(-.1,.05);
	glVertex2f(-.1,-.05);
	glVertex2f(-.15,-.05);

	glVertex2f(-.15,.1);
	glVertex2f(-.7,.1);
	glVertex2f(-.7,-.1);
	glVertex2f(-.15,-.1);


    glEnd();


	glPopMatrix();
   j+=0.3f;
   glLoadIdentity();







glFlush();

}

int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitWindowSize(320, 320);
   glutInitWindowPosition(50, 50);
   glutCreateWindow("Basic Animation");
   glutDisplayFunc(display);
   init();
    glutTimerFunc(50, update, 0);
     glutTimerFunc(50, update3, 0);
      glutTimerFunc(50, update4, 0);
   glutKeyboardFunc(handlekeypress);
   glutMouseFunc(handleMouse);
 glutMainLoop();
   return 0;
}
